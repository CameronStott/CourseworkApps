/*package com.example.locations_defib;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface MyDataAccessObject
{
    @Insert
    public void addLocation(DefibLocation location);

    @Query("select * from defibulator_locations")
    public List<DefibLocation> getLocations();


}*/
