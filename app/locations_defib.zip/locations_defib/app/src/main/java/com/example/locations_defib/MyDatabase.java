/*package com.example.locations_defib;

import androidx.room.Database;
import androidx.room.Entity;
import androidx.room.RoomDatabase;

@Database(entities = {DefibLocation.class},version = 1)
public abstract class MyDatabase extends RoomDatabase
{

    public abstract  MyDataAccessObject MyDao();

}*/
