package com.example.locations_defib.directionhelpers;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}